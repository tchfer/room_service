package com.jrdutra.crud.saladereuniao.salareuniao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalareuniaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalareuniaoApplication.class, args);
	}

}
